const jwt = require("jsonwebtoken")
const SECRET_KEY="kamfirinfdcljdjsflsdfljuy575itjkshkjjjdjfkqa"



exports.generateAuthJwt = async (payload) =>{
    const {expires_in, ...params} = payload
    const token = jwt.sign(params,SECRET_KEY,{expiresIn: expires_in} )

if(!token){
    return false
}
return token
}

exports.decodeToken = (req, res, next) => {
    try {
        let token = req.headers.token
        if (!token) {
          res.send({ responseCode: 401, responseMessage: 'MISSING_TOKEN', responseResult: [] })
          }
        jwt.verify(token, SECRET_KEY, async (error, decoded) => {
            if (error) {
                let msgCode="INVALID_TOKEN"
                if(error.message=="jwt expired"){
                    msgCode='TOKEN_EXPIRED'
                }
          res.send({ responseCode: 401, responseMessage: msgCode, responseResult: [] })
                
              
            }
            const {_id} = decoded
            req.token = decoded;
            return next();
        })
    } catch (err) {
        console.log("______________________", err)
        res.send({ responseCode: 401, responseMessage: "internal server error", responseResult: [] })


    }
}
