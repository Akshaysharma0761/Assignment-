const express = require('express')
const app = express();

 // DB CONNECTION
 require('./dbConnection/db')
const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extented: false }));
app.use(bodyParser.json())

app.use(express.json())

 
// // TESTING
app.get('/', (req, res) => {
  res.setHeader('Content-Type', 'application/json')
  res.json(['SERVER IS LIVE!'])
})

// ROUTING API URL OF EACH MODULE
let userRouter1 = require('./user/userRouter/router');

app.use('/user',userRouter1);

// LAUNCHING THE SERVER
const PORT=8001
app.listen(PORT, (err, result) => {
    if (err) {
        console.log("port is not listening");
    }
    else {
        console.log('port is listening', PORT);
    }
 });
