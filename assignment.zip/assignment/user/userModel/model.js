const mongoose = require('mongoose')

const userSchema = new mongoose.Schema({
   name:{
    type:String
   },
   gender:{
    type:String
   },
   email:{
    type:String
   },
   password:{
    type:String
   },
   phoneNumber:{
    type:Number
   },
   address:{
    type:String
   }
  });

let user = mongoose.model('user', userSchema)
module.exports={
    user
}
