const mongoose = require('mongoose')
const Schema = mongoose.Schema;
const dummySchema = new mongoose.Schema({
   name:{
    type:String
   },
   manager: { type: Schema.Types.ObjectId, ref: 'Employee' },
  });

let data = mongoose.model('data', dummySchema)
module.exports={
    data
}
