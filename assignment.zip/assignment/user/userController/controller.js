const { user } = require("../userModel/model")
const bcrypt = require('bcryptjs')
const secretKey="kamfirinfdcljdjsflsdfljuy575itjkshkjjjdjfkqa"
var ffmpeg = require('fluent-ffmpeg');
//convert into m3u8
const jwt = require("../../helper/jwt")
const fs = require('fs');
const path = require('path');
const {data}= require("../userModel/data")

 exports.addUser= async (req, res) => {
    try {
      const check = await user.findOne({email:req.body.email}).lean()
      if(check){
        res.send({ responseCode: 409, responseMessage: 'already have an account', responseResult: [] })
      }
      else{
        req.body.password = bcrypt.hashSync(req.body.password)
        let userInfo = await user(req.body).save();
        res.send({ responseCode: 200, responseMessage: 'successfully product Created', responseResult: userInfo })
      }
     
    }
    catch (error) {
      console.log(error)
      res.send({ responseCode: 500, responseMessage: 'Something went wrong', responseResult: [] })
    }
  },
  exports.login= async (req, res) => {
    try {

      let findResult = await user.findOne({ email: req.body.email }).lean()
      if (findResult) {
        let passCheck = bcrypt.compareSync(req.body.password, findResult.password);
        if (passCheck) {
            const token = await jwt.generateAuthJwt({
                email: findResult.email,
                _id: findResult._id,
                expires_in: "1h"

            })
          res.send({ responseCode: 200, responseMessage: 'login successfully', responseResult: {findResult,token} })

        }
        else {
          res.send({ responseCode: 400, responseMessage: ' password incorrect', responseResult: [] })

        }
      }
      else {
        res.send({ responseCode: 401, responseMessage: 'data not found', responseResult: [] })

      }
    }
    catch (error) {
      console.log(error)
      res.send({ responseCode: 500, responseMessage: 'Something went wrong', responseResult: [] })
    }
  }
  exports.videoUpload = async (req, res) => {
    try {
        if (!req.file) {
          return res.status(400).json({ message: 'No file uploaded' });
        }
    
        const inputVideoPath = req.file.path;
        const outputDir = 'public/videos/';
        const outputVideoPath = path.join(outputDir, 'video.m3u8');
    
        if (!fs.existsSync(outputDir)) {
          fs.mkdirSync(outputDir, { recursive: true });
        }
    
        ffmpeg(inputVideoPath)
          .output(outputVideoPath)
          .outputOptions([
            '-map 0:0',
            '-c:v libx264',
            '-b:v 2000k',
            '-s:v 2160x3840',
            '-vf', 'scale=640:360',
            '-f hls',
            '-max_muxing_queue_size 1024',
            '-hls_time 1',
            '-hls_list_size 0',
            '-hls_segment_filename', 'v%v/fileSequence%d.ts',
          ])
          .on('start', (commandLine) => {
            console.log('Spawned Ffmpeg with command: ' + commandLine);
          })
          .on('error', (err, stdout, stderr) => {
            console.log('An error occurred: ' + err.message, err, stderr);
            res.status(500).json({ message: 'Error converting video', error: err.message });
          })
          .on('progress', (progress) => {
            console.log('Processing: ' + progress.percent + '% done');
          })
          .on('end', () => {
            console.log('Finished processing!');
    
            // Optionally, you can keep the original video file
            const originalVideoPath = path.join(outputDir, req.file.originalname);
            fs.renameSync(inputVideoPath, originalVideoPath);
    
            res.status(200).json({ message: 'Video uploaded and converted successfully' });
          })
          .run();
      }catch (error) {
    console.error('Error uploading video:', error);
    res.status(500).json({ message: 'Something went wrong', error: error.message });
  }
};

exports.selfRefencingTable=async(req,res)=>{
 try {
  async function displayHierarchy(employeeId, indent = '') {
    const employee = await data.findById(employeeId);
    if (!employee) {
      return '';
    }
  
    let hierarchy = `${indent}-${employee.name}\n`;
  
    const subordinates = await data.find({ manager: employeeId });
    for (const subordinate of subordinates) {
      hierarchy += await displayHierarchy(subordinate._id, `${indent}  `);
    }
  
    return hierarchy;
  }
const Result= await data.findOne({name:req.body.name}).lean()
if(Result){
  let finalResult=await displayHierarchy(Result._id)
  console.log(finalResult)
  res.send({ responseCode: 200, responseMessage: `successful get `, responseResult: finalResult })

}
else{
  res.send({ responseCode: 404, responseMessage: `${req.body.name} not found in the database.`, responseResult: [] })
  
}
 } catch (error) {
  res.status(500).json({ message: 'Something went wrong', error: error.message });
  
 }
 
}


