const userRouter=require("express").Router()
const controller= require("../userController/controller")
const multer= require('multer')
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, 'uploads/'); // Specify the destination directory for uploaded files
    },
    filename: function (req, file, cb) {
      const stringWithoutSpaces = file.originalname;
      const newFileName = stringWithoutSpaces;
      cb(null, newFileName);
    },
  });
  
  const uploadVideo = multer({
    storage: storage,
  }).single('video');
userRouter.post("/addUser",controller.addUser);
userRouter.post("/login",controller.login);
userRouter.post("/videoUpload",uploadVideo,controller.videoUpload);
userRouter.get("/selfRefencingTable",controller.selfRefencingTable);




module.exports=userRouter